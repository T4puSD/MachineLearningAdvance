import tensorflow as tf
import numpy as np
g=tf.Graph()
#z=2(a-b)+c
with g.as_default():
    tf_x=tf.placeholder(tf.float32,shape=[None,2],name='tf_x')
    x_mean=tf.reduce_mean(tf_x,axis=0,name='mean')
import numpy as np
np.random.seed(123)
np.set_printoptions(precision=2)
with tf.Session(graph=g) as sess:
     x1=np.random.uniform(low=0,high=1,size=(10,2))
     print('Feeding data shape',x1.shape)
     print('Feeding Data',x1)
     print('result',sess.run(x_mean,feed_dict={tf_x:x1}))

    
