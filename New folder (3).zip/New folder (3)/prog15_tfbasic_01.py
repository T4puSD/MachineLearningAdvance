import tensorflow as tf
import numpy as np
g=tf.Graph()
#z=2x*x+3x+5
with g.as_default():
    tf_x=tf.placeholder(tf.int32,shape=[],name='tf_x')
    y=2*tf_x*tf_x+3*tf_x+5
    
with tf.Session(graph=g) as sess:
    feed={tf_x:1.5}
    print('Output:' ,sess.run(y,feed_dict=feed))
    
