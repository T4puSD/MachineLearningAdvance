import tensorflow as tf
import numpy as np

g=tf.Graph()
with g.as_default():
     w1=tf.Variable(1,name='W1')
     w2=tf.Variable(2,name='W2')
     w3=tf.Variable(3,name='W3')
     
     
with tf.Session(graph=g) as sess:
     sess.run(tf.global_variables_initializer())
     print(sess.run(w1))
     print(sess.run(w2))
     print(sess.run(w3))
                            
    
