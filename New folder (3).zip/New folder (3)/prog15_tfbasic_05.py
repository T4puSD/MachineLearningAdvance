import tensorflow as tf
g1=tf.Graph()
with tf.Session(graph=g1) as sess:
     new_saver=tf.train.import_meta_graph(
          './train_model.meta')
     new_saver.restore(sess,'./train_model')
     print(sess.run(w1))
     
     
     
               
               
               
