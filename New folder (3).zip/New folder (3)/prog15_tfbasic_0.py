import tensorflow as tf
import numpy as np
## create a graph
g=tf.Graph()
with g.as_default():
     t1=tf.constant(np.pi)
     t2=tf.constant([1,2,3,4,5])
     t3=tf.constant([[1,2],[3,4]])
     t4=tf.constant('TensorFlow')
     r1=tf.rank(t1)
     r2=tf.rank(t2)
     r3=tf.rank(t3)
     r4=tf.rank(t4)
     s1=t1.get_shape()
     s2=t2.get_shape()
     s3=t3.get_shape()
     print(t1,t2,t3,t4)
     print(s1,s2,s3)
     print(r1,r2,r2,r4)
	
# create a session and pass in graph g
with tf.Session(graph=g) as sess:
     print('Ranks: ',r1.eval(),r2.eval(),r3.eval(),r4.eval())
     print('Ranks: ',t1.eval(),t2.eval(),t3.eval(),t4.eval())
     
    
